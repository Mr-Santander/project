<?php

namespace App\Models\Voyager;

use Illuminate\Database\Eloquent\Model;


class PostTag extends Model
{
    
}
