<?php

namespace App\Models\Voyager;

use Illuminate\Database\Eloquent\Model;


class PostDeporte extends Model
{
    
}
