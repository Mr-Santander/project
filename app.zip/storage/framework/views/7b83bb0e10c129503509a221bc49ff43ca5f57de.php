<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class=" fm-video">
        <script>window.addEventListener("resize",ons);function ons(){
            let players = Array.prototype.slice.call( document.getElementsByClassName("iframePlayerCustom"));
            players.forEach(function(player) {
                let wdt = player.offsetWidth/(16/9);player.style.height=(wdt+"px");
                });}ons();
        </script>

        <iframe class="iframePlayerCustom" src="https://player.instantvideocloud.net/#/embed/00d77fad" frameborder="0" width="100%" height="100%" allowfullscreen  onload="ons()">
        </iframe> 
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\canalTro\resources\views/en-vivo.blade.php ENDPATH**/ ?>