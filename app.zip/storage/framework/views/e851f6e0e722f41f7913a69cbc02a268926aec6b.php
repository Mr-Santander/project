<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('pagina'); ?>
        Inicio
    <?php $__env->stopSection(); ?>


    <div class="swiper shadow-2xl">
        <ul class="swiper-wrapper">
            <li class="swiper-slide">
                <img src="https://cdn.pixabay.com/photo/2020/04/28/19/15/man-5106022_960_720.jpg"
                    class="w-full h-screen object-cover object-center" alt="">
            </li>

            <li class="swiper-slide">
                <img src="https://cdn.pixabay.com/photo/2022/06/06/07/17/rome-7245470_960_720.jpg"
                    class="w-full h-screen object-cover object-center" alt="">
            </li>

            <li class="swiper-slide">
                <img src="https://cdn.pixabay.com/photo/2022/06/06/07/17/rome-7245470_960_720.jpg"
                    class="w-full h-screen object-cover object-center" alt="">
            </li>
        </ul>

        <div class="bg-gradient-to-t from-black to-transparent h-12 relative -top-12 z-10">
            <div class="swiper-pagination"></div>
        </div>
    </div>

    


    <div class="max-w-sm bg-white rounded-lg border border-gray-200 shadow-md dark:bg-gray-800 dark:border-gray-700">
        <a href="#">
            <img class="rounded-t-lg"
                src="https://www.tooltyp.com/wp-content/uploads/2014/10/1900x920-8-beneficios-de-usar-imagenes-en-nuestros-sitios-web.jpg"
                alt="">
        </a>
        <div class="p-5">

            <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">Here are the biggest enterprise technology
                acquisitions of 2021 so far, in reverse chronological order.</p>

        </div>
    </div>



    <?php $__env->startPush('js'); ?>
        <script>
            new Swiper('.swiper', {

                // Optional parameters
                loop: true,
                autoplay: {
                    delay: 8000,
                    disableOnInteraction: false,
                },
                // If we need pagination
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                // Navigation arrows
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },
            });
        </script>
    <?php $__env->stopPush(); ?>




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\TRO-DEV\Pictures\canalTro\resources\views/welcome.blade.php ENDPATH**/ ?>