<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<section class=" page_404">
	<div class="container mt-10">
		<div class="flex flex-wrap ">	
		<div class="sm:w-full pr-4 pl-4 ">
		<div class="sm:w-4/5 pr-4 pl-4 col-sm-offset-1  text-center">
		<div class="four_zero_four_bg">
			<h1 class="text-center text-green-700 ">Error 404</h1>
		
		
		</div>
		
		<div class="contant_box_404">
		<h1 class="h2 font-semibold text-2xl">
		¡Parece que la pagina que buscas no existe!
		</h1>
		
		<a href="/" class="link_404">Ir A La Pagina Principal</a>
	</div>
		</div>
		</div>
		</div>
	</div>
</section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\canalTro\resources\views/errors/404.blade.php ENDPATH**/ ?>