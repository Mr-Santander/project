<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['active'=>false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['active'=>false]); ?>
<?php foreach (array_filter((['active'=>false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $clases = $active
                ?'block py-2 pr-4 pl-3 text-white bg-green-700 rounded md:bg-transparent md:text-green-700 md:p-0 md:dark:text-white dark:bg-blue-600 md:dark:bg-white'
                :'block py-2 pr-4 pl-3 lg:text-white md:text-white sm:text-white  rounded hover:bg-transparent md:hover:bg-transparent md:border-0 md:hover:text-green-700 md:p-0 dark:text-green-700 md:dark:hover:text-green-700 dark:hover:bg-gray-700 dark:hover:text-green-700 md:dark:hover:bg-withe ';
?>

<a <?php echo e($attributes->merge(['class' => $clases])); ?>>
    <?php echo e($slot); ?>

</a><?php /**PATH C:\Users\irisg\OneDrive\Escritorio\canalTro\resources\views/components/page/actnav.blade.php ENDPATH**/ ?>