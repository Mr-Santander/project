<x-app-layout>
<section class=" page_404">
	<div class="container mt-10">
		<div class="flex flex-wrap ">	
		<div class="sm:w-full pr-4 pl-4 ">
		<div class="sm:w-4/5 pr-4 pl-4 col-sm-offset-1  text-center">
		<div class="four_zero_four_bg">
			<h1 class="text-center text-green-700 ">Error 404</h1>
		
		
		</div>
		
		<div class="contant_box_404">
		<h1 class="h2 font-semibold text-2xl">
		¡Parece que la pagina que buscas no existe!
		</h1>
		
		<a href="/" class="link_404">Ir A La Pagina Principal</a>
	</div>
		</div>
		</div>
		</div>
	</div>
</section>
</x-app-layout>